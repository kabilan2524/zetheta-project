CREATE TABLE transaction_events (
 event_id UUID PRIMARY KEY, transaction_id UUID NOT NULL, from_state VARCHAR(32),
 to_state VARCHAR(32) NOT NULL, reason VARCHAR(500), created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_txevents_tx_created ON transaction_events(transaction_id,created_at);
