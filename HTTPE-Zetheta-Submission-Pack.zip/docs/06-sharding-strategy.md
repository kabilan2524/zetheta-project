# Day 6 — Sharding Strategy
Primary key: hash(account_id). Start with 16 logical shards and validate physical capacity from benchmark results. Required shards for a 24K engineering design point are ceil(24000 / measured_safe_tps_per_shard), plus operational headroom.

Cross-shard transfers require a coordinator/state machine or a distributed SQL transaction where supported. Do not describe a Saga as equivalent to a single ACID transaction.

Hot merchants require rate limiting, queueing, and—only where business semantics allow—sub-account partitioning. Rebalancing uses copy/verify/fence/cutover steps with checksums and rollback checkpoints.
