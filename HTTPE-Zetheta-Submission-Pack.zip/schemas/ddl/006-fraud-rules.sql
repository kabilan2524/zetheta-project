CREATE TABLE fraud_rules (
 rule_id UUID PRIMARY KEY, rule_name VARCHAR(128) NOT NULL, enabled BOOLEAN NOT NULL DEFAULT TRUE,
 priority INTEGER NOT NULL, rule_definition JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_fraud_rules_active ON fraud_rules(enabled,priority);
