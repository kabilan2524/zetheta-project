def transfer(cmd):
    tx = idempotency.get_or_create(cmd.key)
    if tx.terminal: return tx.result
    transition(tx, "PROCESSING")
    try:
        risk = fraud.check(cmd, timeout_ms=15)
        if risk.reject: return fail(tx, "FRAUD_DETECTED")
        result = ledger.transfer(cmd)
        if not result.success: return fail(tx, result.reason)
        transition(tx, "COMPLETED")
        outbox.publish_intent("transaction.completed", tx.id)
        return tx.result
    except Timeout:
        transition(tx, "UNKNOWN")
        reconciliation.schedule(tx.id)
        return tx.result
