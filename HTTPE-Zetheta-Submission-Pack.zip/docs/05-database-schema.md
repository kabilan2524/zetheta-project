# Day 5 — Database Schema
Use NUMERIC for money. Keep available and ledger balances separate. Enforce positive amounts and valid states with constraints. Index account history, transaction status, ledger account/time and notification retry state. Partition transactions and ledger_entries by creation month. Reconcile every committed transaction so total debit equals total credit.

Financial records are append-oriented. Corrections use compensating entries rather than rewriting historical ledger entries.
