# Day 2 — Technology Evaluation

## Database
| Option | Strength | Trade-off | Decision |
|---|---|---|---|
| PostgreSQL+Citus | Existing expertise, PostgreSQL semantics, sharding | Cross-shard design | Preferred |
| CockroachDB | Distributed SQL and transactions | Higher operational/financial cost | Alternative |
| TiDB | Horizontal SQL | Different operational model | Alternative |

## Messaging
| Option | Strength | Trade-off | Decision |
|---|---|---|---|
| Kafka | Partitions, replay, consumer groups, high throughput | More operations | Preferred |
| RabbitMQ | Familiar, strong queue semantics | Current topology bottlenecks | Replace |
| SQS | Highly managed | Less topology/control | Alternative |

## Cache
| Option | Strength | Trade-off | Decision |
|---|---|---|---|
| Redis/Valkey Cluster | Low latency, rich data structures | Cluster operations | Preferred |
| Memcached | Simple/fast | Limited data structures | Alternative |
| Hazelcast | JVM integration | More platform-specific | Alternative |

Evaluation criteria: performance, operational complexity, cost, Java/PostgreSQL expertise compatibility, community/support.
