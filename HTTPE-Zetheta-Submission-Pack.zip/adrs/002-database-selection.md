# ADR — Choose PostgreSQL+Citus as the primary design because the existing team knows PostgreSQL and the scenario already uses it. Retain CockroachDB as an alternative if benchmark evidence shows cross-shard transaction complexity dominates.
**Status:** Accepted

## Context
The system must meet 12K TPS sustained, 18K burst and p99 <=100ms while preserving committed financial state.

## Decision
Choose PostgreSQL+Citus as the primary design because the existing team knows PostgreSQL and the scenario already uses it. Retain CockroachDB as an alternative if benchmark evidence shows cross-shard transaction complexity dominates.

## Consequences
The decision improves horizontal scale and service isolation, but adds operational complexity, observability requirements and failure modes.

## Compliance
Keep payment data within the selected India deployment region; use TLS 1.3, AES-256 at rest, mTLS internally and immutable audit records as required by the supplied brief. Final regulatory interpretation requires compliance review.
