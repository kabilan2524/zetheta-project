# ADR — Use cache-aside with TTL plus event-driven invalidation. The database remains authoritative. Write-behind is rejected for balances because it can weaken financial consistency.
**Status:** Accepted

## Context
The system must meet 12K TPS sustained, 18K burst and p99 <=100ms while preserving committed financial state.

## Decision
Use cache-aside with TTL plus event-driven invalidation. The database remains authoritative. Write-behind is rejected for balances because it can weaken financial consistency.

## Consequences
The decision improves horizontal scale and service isolation, but adds operational complexity, observability requirements and failure modes.

## Compliance
Keep payment data within the selected India deployment region; use TLS 1.3, AES-256 at rest, mTLS internally and immutable audit records as required by the supplied brief. Final regulatory interpretation requires compliance review.
