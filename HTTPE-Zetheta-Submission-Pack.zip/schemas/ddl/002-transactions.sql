CREATE TABLE transactions (
 transaction_id UUID PRIMARY KEY, idempotency_key VARCHAR(128) UNIQUE NOT NULL,
 transaction_type VARCHAR(24) NOT NULL, source_account_id UUID, destination_account_id UUID,
 amount NUMERIC(18,4) NOT NULL CHECK (amount > 0), status VARCHAR(16) NOT NULL,
 saga_id UUID NOT NULL, failure_reason VARCHAR(500), created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 completed_at TIMESTAMPTZ, metadata JSONB NOT NULL DEFAULT '{}'::jsonb);
CREATE INDEX idx_tx_source_created ON transactions(source_account_id,created_at DESC);
CREATE INDEX idx_tx_status_created ON transactions(status,created_at);
