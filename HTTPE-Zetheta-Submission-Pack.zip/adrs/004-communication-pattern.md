# ADR — Use a hybrid model: synchronous auth, fraud, balance validation and financial commit; asynchronous Kafka for notifications, analytics, reconciliation and webhooks. This bounds the critical-path latency.
**Status:** Accepted

## Context
The system must meet 12K TPS sustained, 18K burst and p99 <=100ms while preserving committed financial state.

## Decision
Use a hybrid model: synchronous auth, fraud, balance validation and financial commit; asynchronous Kafka for notifications, analytics, reconciliation and webhooks. This bounds the critical-path latency.

## Consequences
The decision improves horizontal scale and service isolation, but adds operational complexity, observability requirements and failure modes.

## Compliance
Keep payment data within the selected India deployment region; use TLS 1.3, AES-256 at rest, mTLS internally and immutable audit records as required by the supplied brief. Final regulatory interpretation requires compliance review.
