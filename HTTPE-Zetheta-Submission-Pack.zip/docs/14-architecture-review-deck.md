# Day 14/15 — ARB Deck Outline
1. Mission and constraints
2. Current bottlenecks
3. 13-component target architecture
4. ACID ledger/idempotency/OCC
5. Sharding and hot-key strategy
6. Kafka topology and outbox
7. Fault tolerance and chaos
8. Performance budget
9. Capacity and $45K constraint
10. FMEA
11. Key trade-offs and rejected alternatives
12. Validation results and next steps

Prepare for questions on hot merchants, shard failure, Kafka vs RabbitMQ, 15ms fraud, budget reduction, OCC correctness, circuit-breaker abuse and adapting the architecture to an exchange.
