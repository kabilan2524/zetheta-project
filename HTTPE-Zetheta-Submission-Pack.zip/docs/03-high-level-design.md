# Day 3 — High-Level Design
1. API Gateway — TLS, auth, rate limits, canary routing.
2. Load Balancer — L7 balancing, health checks, draining.
3. Transaction Orchestrator — state machine, idempotency, Saga coordination.
4. Payment Processing — validation, fees, debit/credit/provider integration.
5. Account Service — lifecycle, balances, freezes and tiers.
6. Notification Service — WebSockets/push/SMS/email asynchronously.
7. Fraud Service — rules/ML with Redis feature data and 15ms target.
8. Reconciliation — double-entry and cross-service verification.
9. Audit/Compliance — immutable state history and reports.
10. Kafka — durable event backbone, partitions, DLQs.
11. Database — PostgreSQL+Citus, pooling, replicas, backups.
12. Redis/Valkey — hot metadata, rate limits and fraud features.
13. Observability — Prometheus/Grafana/OpenTelemetry/logging.

Critical path: Gateway -> auth -> idempotency -> fraud -> account/OCC -> ACID ledger commit -> response. Outbox publication is durable but asynchronous.

Deployment: three AZs in an India AWS region; stateless application scaling; replicated database and Kafka; clustered cache.
