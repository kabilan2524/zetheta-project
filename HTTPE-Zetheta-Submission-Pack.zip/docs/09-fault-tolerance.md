# Day 9 — Fault Tolerance
Circuit breakers:
- Fraud: 3 failures/10s, reset 15s, manual-review policy.
- Notification: 5/30s, reset 60s, queue retry.
- Cache: 3/5s, reset 20s, bypass to DB.
- Settlement: 2/5s, reset 60s, defer to next batch.

Bulkheads: separate pools for API, fraud, provider calls, Kafka consumers and notifications. Retry only idempotent or deduplicated operations. Unknown external-payment outcomes enter reconciliation instead of being marked failed.

Chaos experiments: API instance kill, Kafka broker kill, DB latency injection, Redis node failure, network packet loss, paused Kafka consumer and provider timeout.
