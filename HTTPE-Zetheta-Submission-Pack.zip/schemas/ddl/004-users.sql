CREATE TABLE users (
 user_id UUID PRIMARY KEY, external_ref VARCHAR(128) UNIQUE NOT NULL,
 kyc_status VARCHAR(16) NOT NULL, country_code CHAR(2) NOT NULL DEFAULT 'IN',
 pii_token VARCHAR(128), created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_users_kyc ON users(kyc_status);
