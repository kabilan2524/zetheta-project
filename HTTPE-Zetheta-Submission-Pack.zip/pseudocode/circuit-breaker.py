class Circuit:
    CLOSED, OPEN, HALF_OPEN = range(3)
    def call(self, operation):
        if self.state == OPEN and now() < self.next_probe:
            raise DependencyUnavailable()
        if self.state == OPEN: self.state = HALF_OPEN
        try:
            result = operation(timeout=self.timeout)
            self.success()
            return result
        except RetryableDependencyError:
            self.failure()
            raise
