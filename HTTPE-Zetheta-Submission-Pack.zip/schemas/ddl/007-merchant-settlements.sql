CREATE TABLE merchant_settlements (
 settlement_id UUID PRIMARY KEY, merchant_account_id UUID NOT NULL,
 batch_ref VARCHAR(128) UNIQUE NOT NULL, transaction_count INTEGER NOT NULL CHECK (transaction_count BETWEEN 0 AND 100000),
 gross_amount NUMERIC(20,4) NOT NULL, fee_amount NUMERIC(20,4) NOT NULL, net_amount NUMERIC(20,4) NOT NULL,
 status VARCHAR(24) NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), completed_at TIMESTAMPTZ);
CREATE INDEX idx_settlement_merchant_created ON merchant_settlements(merchant_account_id,created_at DESC);
