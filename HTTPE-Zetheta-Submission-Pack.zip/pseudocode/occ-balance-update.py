def debit(account_id, amount):
    row = db.select("available_balance, version, status", account_id)
    assert row.status == "ACTIVE"
    assert row.available_balance >= amount
    n = db.execute(
        "UPDATE accounts SET available_balance=available_balance-:a, version=version+1 "
        "WHERE account_id=:id AND version=:v AND available_balance>=:a",
        a=amount, id=account_id, v=row.version)
    if n == 0:
        raise ConcurrentModification()
    return "DEBITED"
