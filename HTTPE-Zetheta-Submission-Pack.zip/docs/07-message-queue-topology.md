# Day 7 — Kafka Topology
Topics: txn.lifecycle, ledger.events, fraud.requests, notifications, settlement.events, reconciliation and corresponding DLQs.

Proposed starting partitions: 32 for high-volume transaction/ledger/fraud topics, 16 for settlement/reconciliation/notifications. Key by account_id where ordering is required. Replication factor 3; min.insync.replicas 2.

Use transactional outbox: DB transaction writes financial state and outbox record together; relay publishes with idempotent producer; consumers deduplicate side effects. Retry transient errors with jitter; route poison messages to DLQ.
