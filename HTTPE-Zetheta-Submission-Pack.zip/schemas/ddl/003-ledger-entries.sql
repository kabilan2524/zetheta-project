CREATE TABLE ledger_entries (
 entry_id UUID PRIMARY KEY, transaction_id UUID NOT NULL, account_id UUID NOT NULL,
 direction VARCHAR(8) NOT NULL CHECK (direction IN ('DEBIT','CREDIT')),
 amount NUMERIC(18,4) NOT NULL CHECK (amount > 0), currency CHAR(3) NOT NULL,
 sequence_no BIGINT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_ledger_account_created ON ledger_entries(account_id,created_at DESC);
CREATE INDEX idx_ledger_tx ON ledger_entries(transaction_id);
