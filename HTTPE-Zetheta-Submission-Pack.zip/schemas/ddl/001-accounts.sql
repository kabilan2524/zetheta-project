CREATE TABLE accounts (
 account_id UUID PRIMARY KEY, user_id UUID NOT NULL,
 account_type VARCHAR(24) NOT NULL CHECK (account_type IN ('SAVINGS','CURRENT','WALLET','MERCHANT','SETTLEMENT_POOL')),
 currency CHAR(3) NOT NULL DEFAULT 'INR',
 available_balance NUMERIC(18,4) NOT NULL CHECK (available_balance >= 0),
 ledger_balance NUMERIC(18,4) NOT NULL, version BIGINT NOT NULL DEFAULT 1,
 status VARCHAR(16) NOT NULL CHECK (status IN ('ACTIVE','FROZEN','SUSPENDED','CLOSED')),
 tier VARCHAR(16) NOT NULL, shard_key INTEGER NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX idx_accounts_user ON accounts(user_id);
CREATE INDEX idx_accounts_shard_status ON accounts(shard_key,status);
