# AWS Pricing Validation
The assignment requires public AWS pricing and permits estimates within 20%. Final figures should be validated in AWS Pricing Calculator immediately before submission. AWS documentation confirms EC2 instances are available in Mumbai and EC2 On-Demand is billed by running time; ElastiCache pricing varies by node/deployment model.

Record the exact calculator inputs here before final submission:
- Region: ap-south-1
- EC2 family/size:
- instance count:
- RDS/Citus or database platform:
- Kafka deployment:
- cache nodes:
- EBS/storage:
- load balancer:
- monitoring/logging:
- monthly estimate:
