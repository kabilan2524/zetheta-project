def handle(request):
    key = request.headers["Idempotency-Key"]
    fingerprint = hash(request.method + request.path + request.body)
    existing = durable_store.get(key)
    if existing:
        if existing.fingerprint != fingerprint:
            raise Conflict("IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_REQUEST")
        return existing.response
    durable_store.put_if_absent(key, fingerprint, ttl_hours=24)
    response = execute_financial_operation()
    durable_store.complete(key, response)
    return response
