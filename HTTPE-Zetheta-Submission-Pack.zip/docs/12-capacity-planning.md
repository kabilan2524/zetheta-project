# Day 12 — Capacity Planning
Scale points: 1,200 / 12,000 / 24,000 TPS.

Illustrative planning topology:
| Scale | App instances | Logical DB shards | Kafka brokers | Cache nodes |
|---|---:|---:|---:|---:|
| 1.2K | 8 | 4 | 3 | 3 |
| 12K | 32–48 | 16 | 6 | 6 |
| 24K | 64–96 | 24–32 | 9 | 9 |

These are starting topology assumptions, not measured capacities. Final instance counts must be derived from benchmark results.

Use AWS Mumbai (`ap-south-1`) for the India residency requirement. Validate the final monthly total in AWS Pricing Calculator. Optimize with Savings Plans/reserved baseline, right-sizing and Spot for non-critical load-generation/stateless workloads. The 12K production design must stay below the $45K/month ceiling; if the 24K stress case exceeds it, explicitly document the trade-off.
