# Day 13 — FMEA
RPN = Severity × Occurrence × Detection. RPN >200 requires immediate mitigation.

| ID | Failure mode | S | O | D | RPN |
|---|---|---:|---:|---:|---:|
| FM001 | DB primary failure | 10 | 3 | 2 | 60 |
| FM002 | Kafka broker failure | 6 | 5 | 2 | 60 |
| FM003 | Redis node failure | 5 | 5 | 2 | 50 |
| FM004 | AZ partition | 10 | 3 | 4 | 120 |
| FM005 | Account contention | 9 | 7 | 4 | 252 |
| FM006 | Fraud timeout | 7 | 5 | 3 | 105 |
| FM007 | Idempotency collision | 8 | 2 | 5 | 80 |
| FM008 | Kafka disk full | 9 | 3 | 3 | 81 |
| FM009 | mTLS expiry | 10 | 2 | 3 | 60 |
| FM010 | Memory leak | 7 | 5 | 4 | 140 |
| FM011 | Outbox relay crash | 8 | 5 | 2 | 80 |
| FM012 | Duplicate Kafka delivery | 8 | 5 | 4 | 160 |
| FM013 | Provider timeout | 9 | 5 | 4 | 180 |
| FM014 | Clock skew | 6 | 3 | 5 | 90 |
| FM015 | Bad schema migration | 9 | 2 | 5 | 90 |
| FM016 | Hot merchant shard | 8 | 7 | 5 | 280 |
| FM017 | Cache stampede | 6 | 6 | 4 | 144 |
| FM018 | Gateway false rejection | 6 | 4 | 5 | 120 |
| FM019 | Poison message | 7 | 5 | 3 | 105 |
| FM020 | Audit pipeline outage | 8 | 3 | 6 | 144 |
| FM021 | Secrets exposure | 10 | 2 | 6 | 120 |
| FM022 | Data corruption | 10 | 2 | 6 | 120 |
| FM023 | DB pool exhaustion | 9 | 6 | 3 | 162 |
| FM024 | Deployment regression | 8 | 4 | 5 | 160 |
| FM025 | Reconciliation lag | 8 | 4 | 5 | 160 |

High-RPN FM005 and FM016 receive dedicated mitigation and chaos tests.
