# ADR — Use hash(account_id) as the logical shard key. Account ownership is the natural balance-mutation boundary. Start with 16 logical shards and validate physical capacity through benchmarks. Hot merchants require rate limits, queueing or business-valid sub-account partitioning.
**Status:** Accepted

## Context
The system must meet 12K TPS sustained, 18K burst and p99 <=100ms while preserving committed financial state.

## Decision
Use hash(account_id) as the logical shard key. Account ownership is the natural balance-mutation boundary. Start with 16 logical shards and validate physical capacity through benchmarks. Hot merchants require rate limits, queueing or business-valid sub-account partitioning.

## Consequences
The decision improves horizontal scale and service isolation, but adds operational complexity, observability requirements and failure modes.

## Compliance
Keep payment data within the selected India deployment region; use TLS 1.3, AES-256 at rest, mTLS internally and immutable audit records as required by the supplied brief. Final regulatory interpretation requires compliance review.
