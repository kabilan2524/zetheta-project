# ADR — Choose Kafka over RabbitMQ/SQS because the target requires explicit partitioning, replay, consumer groups, retention and DLQ topology. RabbitMQ is the supplied bottleneck; SQS is operationally simpler but provides less direct control over partition-oriented ordering.
**Status:** Accepted

## Context
The system must meet 12K TPS sustained, 18K burst and p99 <=100ms while preserving committed financial state.

## Decision
Choose Kafka over RabbitMQ/SQS because the target requires explicit partitioning, replay, consumer groups, retention and DLQ topology. RabbitMQ is the supplied bottleneck; SQS is operationally simpler but provides less direct control over partition-oriented ordering.

## Consequences
The decision improves horizontal scale and service isolation, but adds operational complexity, observability requirements and failure modes.

## Compliance
Keep payment data within the selected India deployment region; use TLS 1.3, AES-256 at rest, mTLS internally and immutable audit records as required by the supplied brief. Final regulatory interpretation requires compliance review.
