import http from 'k6/http';
import { check } from 'k6';
export const options = {
  scenarios: { target: { executor:'constant-arrival-rate', rate:12000, timeUnit:'1s',
    duration:'30m', preAllocatedVUs:400, maxVUs:1500 } },
  thresholds: { http_req_failed:['rate<0.001'], http_req_duration:['p(99)<100'] }
};
export default function () {
  const body = JSON.stringify({
    transactionType:'P2P', sourceAccountId:__ENV.SOURCE_ACCOUNT,
    destinationAccountId:__ENV.DESTINATION_ACCOUNT, amount:1, currency:'INR'
  });
  const r=http.post(`${__ENV.BASE_URL}/v1/transactions`,body,
    {headers:{'Content-Type':'application/json','Idempotency-Key':`${__VU}-${__ITER}-${Date.now()}`}});
  check(r,{accepted:x=>x.status===200||x.status===201});
}
