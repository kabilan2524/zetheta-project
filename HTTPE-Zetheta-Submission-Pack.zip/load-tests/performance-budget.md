# Performance Budget — p99 <= 100ms
Gateway 5ms
Authentication 3ms
Idempotency 2ms
Fraud 15ms
Account/OCC 10ms
Ledger DB commit 25ms
Orchestration 5ms
Outbox handoff 5ms
Serialization/network 10ms
Subtotal 80ms
Headroom 20ms
Kafka downstream processing is asynchronous after durable outbox commit.
