# Day 1 — Scenario Analysis
PayScale must scale from 1,200 TPS to 12,000 TPS sustained and 18,000 TPS for a 15-minute burst. The current system has a single PostgreSQL primary, single-node RabbitMQ, fixed application servers, single Redis node, gateway throttling errors and account-row contention.

Top bottlenecks:
1. PostgreSQL connection exhaustion and query queueing.
2. RabbitMQ acknowledgement backlog and consumer lag.
3. Application thread-pool saturation.
4. Redis eviction/cache hit-ratio degradation.
5. Account-table lock contention/deadlocks.

Proposed direction: PostgreSQL+Citus or another distributed SQL design for horizontal data capacity; PgBouncer; Kafka with partitioned topics and consumer groups; Redis/Valkey Cluster; stateless horizontally scaled Java/Kotlin services; OCC for account balance updates; transactional outbox; circuit breakers/bulkheads; and continuous reconciliation.

Financial correctness is more important than blindly accepting requests during a partition. The authoritative ledger remains durable and ACID; Kafka and caches support scale but do not become the source of truth.

The final architecture must be proven through load, soak and failure tests rather than only diagrams.
