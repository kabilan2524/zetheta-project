# Day 11 — Load Testing
LT01 baseline 1,200 TPS/15m.
LT02 target 12,000 TPS/30m.
LT03 burst 18,000 TPS/15m.
LT04 headroom 24,000 TPS/10m.
LT05 soak 12,000 TPS/2h.
LT06 duplicate/retry storm 12,000 TPS/15m.
LT07 dependency failure 12,000 TPS/15m.
LT08 hot-account/merchant 12,000 TPS/15m.

Measure throughput, p50/p95/p99/p99.9, errors, DB connections, locks, Kafka lag, Redis memory, CPU/memory and ledger invariants. Actual pass/fail is determined after execution.
