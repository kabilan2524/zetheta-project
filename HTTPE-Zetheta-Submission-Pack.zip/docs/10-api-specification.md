# Day 10 — API Specification
Rate limits: BASIC 50 TPS, PREMIUM 200 TPS, MERCHANT 1,000 TPS, plus global quotas. Use HTTP 429 with Retry-After for throttling.

Error mapping: 400 validation, 401 auth, 403 authorization, 404 missing resource, 409 idempotency/concurrency conflict, 422 business failure, 429 rate limit, 503 dependency outage.

Internal communication uses mTLS. External traffic uses TLS 1.3.
