CREATE TABLE notification_log (
 notification_id UUID PRIMARY KEY, transaction_id UUID NOT NULL, channel VARCHAR(16) NOT NULL,
 destination_token VARCHAR(256), status VARCHAR(16) NOT NULL, attempt_count INTEGER NOT NULL DEFAULT 0,
 last_error VARCHAR(500), created_at TIMESTAMPTZ NOT NULL DEFAULT now(), sent_at TIMESTAMPTZ);
CREATE INDEX idx_notification_status ON notification_log(status,created_at);
