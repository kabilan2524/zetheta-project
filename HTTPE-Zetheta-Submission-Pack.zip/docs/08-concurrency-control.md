# Day 8 — Concurrency Control
OCC uses account.version. The update includes WHERE version = expected_version AND available_balance >= amount. If affected rows = 0, retry from a fresh read.

Correctness: if T1 and T2 read version V, only one can update V -> V+1. The other update affects zero rows and must retry; therefore both cannot successfully spend the same stale balance.

For multi-row operations, lock IDs in deterministic order. Use fencing tokens for distributed leases. Use READ COMMITTED for ordinary reads, stronger isolation for settlement/invariant-sensitive operations.

Sagas manage cross-service workflows; they are not a substitute for an atomic ledger transaction.
